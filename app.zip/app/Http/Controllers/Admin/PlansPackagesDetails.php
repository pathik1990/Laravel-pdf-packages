<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PlansAndPackages;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class PlansPackagesDetails extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $plansAndPackages = PlansAndPackages::with([
            'user'  =>  function( $query ) {
                $query->select('id', 'name', 'email', 'created_at');
            },
            'payments'
        ])->get();

        return view('admin.plans.all', compact('plansAndPackages'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $plansAndPackages = PlansAndPackages::with([
            'user'  =>  function( $query ) {
                $query->select('id', 'name', 'email', 'created_at');
            },
            'payments'
        ])->where('id', '=', $id)->first();

        $percentage = ($plansAndPackages->usage_package / $plansAndPackages->total_package) * 100;
        $plansAndPackagesData = [
            'package_name'      => $plansAndPackages->package_name,
            'total_packages'    => $plansAndPackages->total_package,
            'usage_packages'    => $plansAndPackages->usage_package,
            'percentage'        => $percentage
        ];

        $dataArray = [
            "plans_package" =>
            [
                $plansAndPackagesData,
                "created_at"    => Carbon::parse($plansAndPackages->created_at)->diffForHumans()
            ],
            "user_details" =>
            [
                "user_name"     => $plansAndPackages['user']->name,
                "user_email"    => $plansAndPackages['user']->email,
                "created_at"    => Carbon::parse($plansAndPackages['user']->created_at)->diffForHumans()
            ],
            "payment_details" =>
            [
                "transaction_id"    => $plansAndPackages['payments']->transaction_id,
                "amount"            => $plansAndPackages['payments']->amount,
                "currency"          => $plansAndPackages['payments']->currency,
                "payment_status"    => $plansAndPackages['payments']->payment_status,
                "created_at"        => Carbon::parse($plansAndPackages['payments']->created_at)->diffForHumans()
            ],
        ];

        return response()->json($dataArray);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
