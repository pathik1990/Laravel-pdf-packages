<?php

namespace App\Http\Controllers\Developer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Apikeys;
use SebastianBergmann\RecursionContext\Exception;
use UxWeb\SweetAlert\SweetAlert;

class ApikeysController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $id = Auth::id();
        $apiKeys = Apikeys::select('*')->where('user_id', $id)->where('deleted_at', NULL)->latest()->get();
        if( !empty($apiKeys) ) {
            return view('developer.api_keys')->with('apikeys', $apiKeys);
        } else {
            return view('developer.api_keys');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('developer.new_project');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $apiKeys = new Apikeys();
        $apiKeys->user_id = Auth::id();
        $apiKeys->project_name = $request->input('project_name');
        $apiKeys->public_key = $request->input('public_key');
        $apiKeys->secret_key = $request->input('secret_key');
        $apiKeys->status = true;
        $apiKeys->ip_address = $request->ip();
        $apiKeys->save();
        return redirect()->route('api-keys')->with('status', $request->input('project_name').' Project Added Successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $project = Apikeys::find($id);
        return view('developer.edit_project', compact('project'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $apiKeys = Apikeys::find($id);
        $apiKeys->project_name = $request->input('project_name');
        $apiKeys->update();
        return redirect()->route('api-keys')->with('status',$request->input('project_name').' - Project Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $apiKeys = Apikeys::findOrFail($id);
        $apiKeys->status = false;
        if($apiKeys->update()) {
            $apiKeys->delete();
        }
        return redirect()->route('api-keys')->with('status', $apiKeys->project_name.' - Project Deleted Successfully');
    }
}
