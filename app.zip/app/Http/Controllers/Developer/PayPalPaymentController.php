<?php

namespace App\Http\Controllers\Developer;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\PlansAndPackages;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Srmklive\PayPal\Services\PayPal as PayPalClient;



class PayPalPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('developer.plans.view');
    }

    /**
     * process transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function processTransaction(Request $request)
    {
        $user = Payment::where('user_id', '=', Auth::id())->where('payment_status', '=', 'COMPLETED')->where('deleted_at', NULL)->first();
        if($user != null) {
            return redirect()->route('plans')->with('error', 'You have already purchased plan');
        }

        Session::put('package_name', $request->input('name'));
        Session::put('total_package', $request->input('package_quantity'));

        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $provider->getAccessToken();

        $response = $provider->createOrder([
            "intent" => "CAPTURE",
            "application_context" => [

                "return_url" => route('successTransaction'),
                "cancel_url" => route('cancelTransaction'),
            ],
            "purchase_units" => [
                0 => [
                    'invoice_id' => "PAYPAL_".rand(00000,99999),
                    'soft_descriptor' => 'Stubcreator',
                    "amount" => [
                        "currency_code" => "USD",
                        "value" => $request->input('amount'),
                        "breakdown" => [
                            "item_total"    => [
                                "currency_code" => "USD",
                                "value" => $request->input('amount'),
                            ]
                        ]
                    ],
                    "items" => [
                        0 => [
                            'name' => $request->input('name'),
                            'sku' => "PREPAID_PLAN_".rand(000,999),
                            'unit_amount' => [
                                    'currency_code' => 'USD',
                                    'value' => 6.99,
                               ],
                            'quantity' => $request->input('package_quantity'),
                            'category' => 'DIGITAL_GOODS',
                        ]
                    ]
                ]
            ]
        ]);

        //dd($response);

        if (isset($response['id']) && $response['id'] != null) {

            // redirect to approve href
            foreach ($response['links'] as $links) {
                if ($links['rel'] == 'approve') {
                    return redirect()->away($links['href']);
                }
            }

            return redirect()->route('plans')->with('error',  $response['message']);

        } else {
            return redirect()->route('plans')->with('error',  $response['message']);
        }
    }


    /**
     * success transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function successTransaction(Request $request)
    {
        $provider = new PayPalClient;
        $provider->setApiCredentials(config('paypal'));
        $provider->getAccessToken();
        $response = $provider->capturePaymentOrder($request['token']);

        if (isset($response['status']) && $response['status'] == 'COMPLETED') {
            $payment = new Payment();
            $payment->user_id = Auth::id();
            $payment->invoice_id = $response['purchase_units'][0]['payments']['captures'][0]['invoice_id'];
            $payment->transaction_id = $response['purchase_units'][0]['payments']['captures'][0]['id'];
            $payment->payment_id = $response['id'];
            $payment->payer_id = $response['payer']['payer_id'];
            $payment->payer_email = $response['payer']['email_address'];
            $payment->amount = $response['purchase_units'][0]['payments']['captures'][0]['amount']['value'];
            $payment->currency = env('PAYPAL_CURRENCY');
            $payment->payment_status = $response['status'];
            if( $payment->save() ) {
                $paymentId = $payment->id;
                $plansAndPackages = new PlansAndPackages();
                $plansAndPackages->user_id = Auth::id();
                $plansAndPackages->payment_id = $paymentId;
                $plansAndPackages->package_name = Session::get('package_name');
                $plansAndPackages->usage_package = 0;
                $plansAndPackages->total_package = Session::get('total_package');
                if( $plansAndPackages->save() ){
                    Session::forget('package_name');
                    Session::forget('total_package');
                }
            }
            return redirect()->route('plans')->with('success', "Payment is successful. Your transaction id is: ".$response['purchase_units'][0]['payments']['captures'][0]['id']);
        } else {
            return redirect()->route('plans')->with('error',  $response['message']);
        }
    }

    /**
     * cancel transaction.
     *
     * @return \Illuminate\Http\Response
     */
    public function cancelTransaction(Request $request)
    {
        return redirect()->route('plans')->with('error', 'You have canceled the transaction.');
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
