<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PlansAndPackages extends Model
{

    use HasFactory, SoftDeletes;

    protected $table = 'plans_and_packages';

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function payments()
    {
        return $this->belongsTo(Payment::class, 'payment_id', 'id');
    }
}
